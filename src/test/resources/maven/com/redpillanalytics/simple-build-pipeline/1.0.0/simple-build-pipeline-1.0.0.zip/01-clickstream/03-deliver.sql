
----------------------------------------------------------------------------------------------------------------------------
-- A series of basic clickstream-analytics
--
-- Min, Max, UDFs etc
----------------------------------------------------------------------------------------------------------------------------

-- Aggregate (count&groupBy) using a TABLE-Window
CREATE TABLE ENRICHED_ERROR_CODES_COUNT AS
SELECT code, definition, COUNT(*) AS count
FROM ENRICHED_ERROR_CODES WINDOW TUMBLING (size 30 second)
GROUP BY code, definition
HAVING COUNT(*) > 1;
